
$(function(){
    // load all images.
    var origins=[];
    $("img.container").each(function(){
        var oimg= new Image();
        oimg.src = $(this).attr('src');
        origins.push(oimg);
        $("#hidden-images").append(oimg);
    });


    $("#print").click(function(){
        // get margin
        var page={ 
            top : parseFloat($("#page-top").val()),
            bottom : parseFloat($("#page-bottom").val()),
            left : parseFloat($("#page-left").val()),
            right : parseFloat($("#page-right").val())},
        label={
            top : parseFloat($("#label-top").val()),
            bottom : parseFloat($("#label-bottom").val()),
            left : parseFloat($("#label-left").val()),
            right : parseFloat($("#label-right").val())};
        

        var doc= new jsPDF({orientation: "portrait",unit:"mm",format:"[210,297]"});
        var row= $("img.container").length/2;
		var w=(doc.internal.pageSize.getWidth() - page.left - page.right) /2;
		var h=(doc.internal.pageSize.getHeight() - page.top - page.bottom) /row;
        var iw = w - label.left - label.right;
        var ih = h - label.top - label.bottom;
        var i=0;
        $.each(origins,
            function(){ 
                var x = page.left + w * Math.floor(i%2) + label.left;
                var y = page.top  +  h * Math.floor(i/2) + label.top; 
                doc.addImage(origins[i], 'JPEG', x ,y ,iw,ih);                
                i++;
            });

            var filename= $("#filename").val().trim();
            if(filename=="") filename="labels.pdf";
            else{
                var seg=filename.split(".");
                if(seg.length<2 || seg[seg.length-1].toUpperCase()  != "PDF"){
                    filename = filename + ".pdf";
                }
            }

            doc.save(filename);
        alert("saved as "+ filename);
    });

});