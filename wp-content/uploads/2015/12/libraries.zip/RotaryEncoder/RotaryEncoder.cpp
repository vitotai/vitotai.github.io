#include "RotaryEncoder.h"

#if ARDUINO >= 100
#include "Arduino.h"
#else
#include "WProgram.h"
#endif

#define PushEventAtRelease true

RotaryEncoder::RotaryEncoder(byte pinA,byte pinB, byte pinPush) 
{ 
	EncoderPinA=pinA;
	EncoderPinB=pinB;
	EncoderPinP=pinPush;
	
		pinMode(EncoderPinA, INPUT);
		digitalWrite(EncoderPinA, HIGH);
		pinMode(EncoderPinB, INPUT);
		digitalWrite(EncoderPinB, HIGH);
		pinMode(EncoderPinP, INPUT);
		digitalWrite(EncoderPinP, HIGH);

	_position = 0; 
    _step=0;
	_pushed = false;
    _output=2;
    _longPressedDetected = false;
}

RotaryEncoderStatus RotaryEncoder::read(void)
{ 
		byte pos = (digitalRead(EncoderPinB) * 2) + digitalRead(EncoderPinA);;
		if (pos != _position)
		{
			bool isFwd = ((_position == 0) && (pos == 1)) || ((_position == 1) && (pos == 3)) || 
				((_position == 3) && (pos == 2)) || ((_position == 2) && (pos == 0));
		        _position = pos;
                        if(isFwd) 
                       {
                          _step ++;
                          if(_step >= _output)
                          {
                              _step =0;
                              #if SerialDebugEnable == true
                              Serial.println(F("[FF]"));
                              #endif
                              return RotaryEncoderStatusFordward;
                          }
                       }
                       else
                      {
                         _step--;
                         if(0-_step >= _output)
                         {
                             _step=0;
                              #if SerialDebugEnable == true
                              Serial.println(F("[BB]"));
                              #endif

                             return RotaryEncoderStatusBackward;
                         }
                      }
		}

        bool pushed=!digitalRead(EncoderPinP);
		if (_pushed !=  pushed)
        {
        	// status changed
            _pushed= pushed;

            if( pushed) // if push
            {  
                _pressedTime = millis();

            	#if SerialDebugEnable == true
                Serial.println(F("PUSH"));
                #endif
				
				#if PushEventAtRelease != true            	
            	return RotaryEncoderStatusPushed;
            	#endif
            }
            else
            {
            	#if SerialDebugEnable == true
                Serial.println(F("REL"));
                #endif
                    
				if(_longPressedDetected) // if release && skip up is set
            	{
                	_longPressedDetected = false;
            	}
            	else
            	{
					#if PushEventAtRelease != true            	
            		return RotaryEncoderStatusDepushed;
            		#else
            		return RotaryEncoderStatusPushed;
            		#endif
            	}
         	}   
        }else{
        // status NOT changed
            if(_pushed && !_longPressedDetected)
            {
                if((millis() - _pressedTime) >= LongPressedTime)
                {
                    _longPressedDetected = true;
                    
                    #if SerialDebugEnable == true
                    Serial.println(F("LONG PUSH"));
                    #endif

                	return RotaryEncoderStatusLongPressed;
                }
            }
    	}
    	
    	return RotaryEncoderStatusNone;
}
