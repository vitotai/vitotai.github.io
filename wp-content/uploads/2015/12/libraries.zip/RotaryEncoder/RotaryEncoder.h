#ifndef RotaryEncoder_H
#define RotaryEncoder_H

typedef unsigned char byte;

//#define EncoderPinA 10	// Rotary Encoder Left Pin //
//#define EncoderPinB 11	// Rotary Encoder Right Pin //
//#define EncoderPinP 12	// Rotary Encoder Click //
#define LongPressedTime 1000

#define SerialDebugEnable false

typedef enum{
  RotaryEncoderStatusNone,
  RotaryEncoderStatusPushed,
  RotaryEncoderStatusDepushed,
  RotaryEncoderStatusLongPressed,
  RotaryEncoderStatusFordward,
  RotaryEncoderStatusBackward
}RotaryEncoderStatus;

class RotaryEncoder
{
  private:
  
        int _step;
        byte _output;
		byte _position;
        bool _pushed;
        bool _longPressedDetected;
        unsigned long _pressedTime;
        byte EncoderPinA;
        byte EncoderPinB;
        byte EncoderPinP;
  public:
	RotaryEncoder(byte pinA,byte pinB, byte pinPush);
	RotaryEncoderStatus read(void);
};
#endif