#include "buzz.h"


#define BUZZER_TIME_TOLERANCE 50
#define BEEP_PERIOD 250
#define LONG_PERIOD 500

static const byte _beep[] PROGMEM ={1,6};
static const byte _longBeep[] PROGMEM ={1,20}; // x25 milliseconds
static const byte _alarmSound[] PROGMEM ={2,20,6}; 

//HOP_ALTERTING_TIME
const byte * const _sounds [] PROGMEM ={
_beep,
_longBeep,
_alarmSound
};


Buzzer::Buzzer(int pin)
{
	_pin=pin;
	_playing=false;
	pinMode (_pin, OUTPUT);
	digitalWrite(_pin, LOW);
}

void Buzzer::beep(void)
{
	play(0,false);
}

void Buzzer::longBeep(void)
{
	play(1,false);
}

void Buzzer::alarm(void)
{
	play(2,true);
}

void Buzzer::playSound(void)
{
	_numberofNtesToPlay = pgm_read_byte(_currentSound);
	
	_ptrCurrentNote =_currentSound;

	_ptrCurrentNote ++;	
	_currentPeriod = (word)pgm_read_byte(_ptrCurrentNote) *25;
	
	_playing=true;
	
	_buzzingTime = millis();
	digitalWrite (_pin, HIGH);
	_buzzing=true;
}

void Buzzer::play(SoundId id,boolean repeat=false)
{
	_currentSound=(byte *)pgm_read_word(&(_sounds[id]));
	_repeat = repeat;	
	playSound();
}

void Buzzer::playCustom(const byte *sound,boolean repeat=false)
{
	_currentSound=(byte*)sound;
	_repeat = repeat;	
	playSound();
}


void Buzzer::mute(void)
{
	digitalWrite (_pin, LOW);
	_playing=false;
}

void Buzzer::loop(void)
{
	if(!_playing) return;
	unsigned long now=millis();
	if((now-_buzzingTime) >= (_currentPeriod + BUZZER_TIME_TOLERANCE))
	{
		_numberofNtesToPlay --;
		if(_numberofNtesToPlay ==0)
		{
			if(_repeat)
			{
				_ptrCurrentNote =_currentSound;
				_numberofNtesToPlay = pgm_read_byte(_currentSound);
			}
			else
			{
				// finished, stop
				mute();
				return;
			}
		}
		_buzzingTime = now;
		//else
		_ptrCurrentNote ++;	
		_currentPeriod = (word)pgm_read_byte(_ptrCurrentNote) *25;
				
		if(_buzzing)
		{
			digitalWrite (_pin, LOW);
		}
		else
		{
			digitalWrite (_pin, HIGH);
		}
		_buzzing = ! _buzzing;
	}
}
