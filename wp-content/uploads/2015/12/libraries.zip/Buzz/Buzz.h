#ifndef BUZZ_H
#define BUZZ_H
#if ARDUINO >= 100
#include "Arduino.h"
#else
#include "WProgram.h"
#endif

typedef unsigned char SoundId;



class Buzzer
{
private:
	int _pin;
	byte _numberofNtesToPlay;
	boolean _repeat;
	boolean _playing;
	boolean _buzzing;
	unsigned long _buzzingTime;
	word _currentPeriod;
	byte* _ptrCurrentNote;

	byte* _currentSound;

	void playSound(void);
	
public:
	Buzzer(int pin);
	void beep(void);
	void longBeep(void);
	void alarm(void);
	void play(SoundId id,boolean repeat);
	void playCustom(const byte* sound,boolean repeat);
	void mute(void);
	void loop(void);
};
#endif